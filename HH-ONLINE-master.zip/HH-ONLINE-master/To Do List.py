##To do list##
//# - make word equivilents of popular currencies
//# - make function to list all currencies (make in pages as is long)
//# - make scipt to acivate main on keyword
//# - add an error message for words that are recognised
//#     by speach converter but not currency
//# - add while loop to let user resay something if times out
//# - scrape word equivilents for currencies
//# - 
//#
//#
//#
//#
//#
